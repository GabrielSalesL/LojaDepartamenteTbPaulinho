package com.example.tblpaulinho4periodo;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText clienteNome, clienteCpf, itemCodigo, itemDescricao, itemValor, itemQuantidade, parcelasInput;
    private TextView listaItens, totalItens, valorTotal, parcelasList;
    private Button adicionarItem, concluirPedido;
    private List<ItemVenda> itensVenda = new ArrayList<>();
    private Cliente clienteSelecionado;
    private int codigoPedido = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        clienteNome = findViewById(R.id.clienteNome);
        clienteCpf = findViewById(R.id.clienteCpf);
        itemCodigo = findViewById(R.id.itemCodigo);
        itemDescricao = findViewById(R.id.itemDescricao);
        itemValor = findViewById(R.id.itemValor);
        itemQuantidade = findViewById(R.id.itemQuantidade);
        parcelasInput = findViewById(R.id.parcelasInput);

        listaItens = findViewById(R.id.listaItens);
        totalItens = findViewById(R.id.totalItens);
        valorTotal = findViewById(R.id.valorTotal);
        parcelasList = findViewById(R.id.parcelasList);

        adicionarItem = findViewById(R.id.adicionarItem);
        concluirPedido = findViewById(R.id.concluirPedido);

        adicionarItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (camposSaoValidos()) {
                    int codigo = Integer.parseInt(itemCodigo.getText().toString());
                    String descricao = itemDescricao.getText().toString();
                    double valorUnitario = Double.parseDouble(itemValor.getText().toString());
                    int quantidade = Integer.parseInt(itemQuantidade.getText().toString());

                    ItemVenda item = new ItemVenda(codigo, descricao, valorUnitario, quantidade);
                    itensVenda.add(item);

                    atualizarListaItens();
                    calcularTotal();
                } else {
                    exibirMensagem("Por favor, preencha todos os campos corretamente.");
                }
            }
        });

        concluirPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (camposSaoValidos()) {
                    String nome = clienteNome.getText().toString();
                    String cpf = clienteCpf.getText().toString();

                    if (TextUtils.isEmpty(nome) || TextUtils.isEmpty(cpf)) {
                        exibirMensagem("Por favor, preencha todos os campos do cliente.");
                    } else {
                        clienteSelecionado = new Cliente(nome, cpf);
                        boolean isAVista = true;
                        int numeroParcelas = 0;
                        if (!TextUtils.isEmpty(parcelasInput.getText().toString())) {
                            isAVista = false;
                            numeroParcelas = Integer.parseInt(parcelasInput.getText().toString());
                        }

                        if (isAVista || numeroParcelas > 0) {
                            Pedido pedido = new Pedido(codigoPedido, clienteSelecionado, itensVenda, isAVista, numeroParcelas);
                            codigoPedido++;

                            exibirMensagem("Pedido #" + pedido.getCodigo() + " cadastrado com sucesso!");
                            limparCampos();
                        } else {
                            exibirMensagem("Por favor, insira o número de parcelas para compras a prazo.");
                        }
                    }
                } else {
                    exibirMensagem("Por favor, preencha todos os campos corretamente.");
                }
            }
        });
    }

    private void atualizarListaItens() {
        StringBuilder listaItensText = new StringBuilder();
        for (ItemVenda i : itensVenda) {
            listaItensText.append(i.getCodigo()).append(" - ").append(i.getDescricao()).append(" x").append(i.getQuantidade()).append("\n");
        }
        listaItens.setText(listaItensText.toString());
    }

    private void calcularTotal() {
        int totalQuantidade = 0;
        double totalValor = 0;
        for (ItemVenda i : itensVenda) {
            totalQuantidade += i.getQuantidade();
            totalValor += i.getQuantidade() * i.getValorUnitario();
        }
        totalItens.setText("Total de Itens: " + totalQuantidade);
        valorTotal.setText("Valor Total: $" + totalValor);
    }

    private boolean camposSaoValidos() {
        return !TextUtils.isEmpty(clienteNome.getText().toString()) &&
                !TextUtils.isEmpty(clienteCpf.getText().toString()) &&
                !TextUtils.isEmpty(itemCodigo.getText().toString()) &&
                !TextUtils.isEmpty(itemDescricao.getText().toString()) &&
                !TextUtils.isEmpty(itemValor.getText().toString()) &&
                !TextUtils.isEmpty(itemQuantidade.getText().toString());
    }

    private void limparCampos() {
        clienteNome.getText().clear();
        clienteCpf.getText().clear();
        itemCodigo.getText().clear();
        itemDescricao.getText().clear();
        itemValor.getText().clear();
        itemQuantidade.getText().clear();
        parcelasInput.getText().clear();
        listaItens.setText("");
        totalItens.setText("Total de Itens: 0");
        valorTotal.setText("Valor Total: $0.0");
        itensVenda.clear();
    }

    private void exibirMensagem(String mensagem) {
        Toast.makeText(MainActivity.this, mensagem, Toast.LENGTH_SHORT).show();
    }
}
