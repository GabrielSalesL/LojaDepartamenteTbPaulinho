package com.example.tblpaulinho4periodo;

public class ItemVenda {
    private int codigo;
    private String descricao;
    private double valorUnitario;
    private int quantidade;

    public ItemVenda(int codigo, String descricao, double valorUnitario, int quantidade) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.valorUnitario = valorUnitario;
        this.quantidade = quantidade;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public double getValorUnitario() {
        return valorUnitario;
    }

    public int getQuantidade() {
        return quantidade;
    }
}