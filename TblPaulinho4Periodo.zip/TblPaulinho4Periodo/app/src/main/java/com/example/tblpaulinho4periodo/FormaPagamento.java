package com.example.tblpaulinho4periodo;

public class FormaPagamento {
    private boolean isAVista;
    private int numeroParcelas;

    public FormaPagamento(boolean isAVista, int numeroParcelas) {
        this.isAVista = isAVista;
        this.numeroParcelas = numeroParcelas;
    }

    public boolean isAVista() {
        return isAVista;
    }

    public int getNumeroParcelas() {
        return numeroParcelas;
    }
}
