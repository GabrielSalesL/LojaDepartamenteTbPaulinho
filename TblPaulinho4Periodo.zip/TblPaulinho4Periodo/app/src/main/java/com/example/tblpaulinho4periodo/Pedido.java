package com.example.tblpaulinho4periodo;

import java.util.List;

public class Pedido {
    private int codigo;
    private Cliente cliente;
    private List<ItemVenda> itensVenda;
    private FormaPagamento formaPagamento;

    public Pedido(int codigo, Cliente cliente, List<ItemVenda> itensVenda, boolean isAVista, int numeroParcelas) {
        this.codigo = codigo;
        this.cliente = cliente;
        this.itensVenda = itensVenda;
        this.formaPagamento = new FormaPagamento(isAVista, numeroParcelas);
    }

    public int getCodigo() {
        return codigo;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public List<ItemVenda> getItensVenda() {
        return itensVenda;
    }

    public FormaPagamento getFormaPagamento() {
        return formaPagamento;
    }
}