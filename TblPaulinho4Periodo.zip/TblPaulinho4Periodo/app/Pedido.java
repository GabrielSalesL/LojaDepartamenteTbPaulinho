import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private static int proximoCodigo = 1;
    private int codigoPedido;
    private Cliente cliente;
    private List<ItemVenda> itens;
    private boolean pagamentoAVista;

    public Pedido(Cliente cliente, boolean pagamentoAVista) {
        this.codigoPedido = proximoCodigo++;
        this.cliente = cliente;
        this.itens = new ArrayList<>();
        this.pagamentoAVista = pagamentoAVista;
    }

    public void adicionarItem(ItemVenda item) {
        itens.add(item);
    }

    public double calcularTotal() {
        double total = 0;
        for (ItemVenda item : itens) {
            total += item.getValorTotal();
        }
        return total;
    }

    public int getCodigoPedido() {
        return codigoPedido;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public boolean isPagamentoAVista() {
        return pagamentoAVista;
    }

    public List<ItemVenda> getItens() {
        return itens;
    }
}
